public class ExceptionSoldeInsuffisant extends Exception{
    public ExceptionSoldeInsuffisant(String message){
        super(message);
    }

}
